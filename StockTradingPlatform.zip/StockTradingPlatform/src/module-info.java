/**
 * 
 */
/**
 * 
 */
module StockTradingPlatform {
}