package StockTradingPlatform;

import java.io.*;
import java.text.NumberFormat;
import java.util.*;

// --------------------- Stock Class ---------------------
class Stock implements Serializable {
    private String symbol;
    private double price;
    private double purchasePrice; // to calculate profit/loss

    public Stock(String symbol, double price) {
        this.symbol = symbol;
        this.price = price;
        this.purchasePrice = price; // initial purchase price
    }

    public String getSymbol() { return symbol; }
    public double getPrice() { return price; }
    public double getPurchasePrice() { return purchasePrice; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString() {
        return symbol + " - " + StockTradingPlatform.currencyFormat.format(price);
    }
}

// --------------------- Portfolio Class ---------------------
class Portfolio implements Serializable {
    private Map<String, Integer> holdings = new HashMap<>();
    private Map<String, Double> avgBuyPrice = new HashMap<>(); // average buy price per stock
    private double balance;

    public Portfolio(double initialBalance) {
        this.balance = initialBalance;
    }

    public double getBalance() { return balance; }

    // Buy Stock
    public void buyStock(Stock stock, int quantity) {
        double cost = stock.getPrice() * quantity;
        if (cost <= balance) {
            balance -= cost;
            holdings.put(stock.getSymbol(), holdings.getOrDefault(stock.getSymbol(), 0) + quantity);

            // Update average buy price
            double prevTotal = avgBuyPrice.getOrDefault(stock.getSymbol(), stock.getPrice()) 
                                * (holdings.get(stock.getSymbol()) - quantity);
            double newAvg = (prevTotal + cost) / holdings.get(stock.getSymbol());
            avgBuyPrice.put(stock.getSymbol(), newAvg);

            System.out.println("Bought " + quantity + " shares of " + stock.getSymbol() +
                               " for " + StockTradingPlatform.currencyFormat.format(cost));
        } else {
            System.out.println("Insufficient balance!");
        }
    }

    // Sell Stock
    public void sellStock(Stock stock, int quantity) {
        if (holdings.containsKey(stock.getSymbol()) && holdings.get(stock.getSymbol()) >= quantity) {
            double revenue = stock.getPrice() * quantity;
            balance += revenue;
            holdings.put(stock.getSymbol(), holdings.get(stock.getSymbol()) - quantity);

            if (holdings.get(stock.getSymbol()) == 0) {
                holdings.remove(stock.getSymbol());
                avgBuyPrice.remove(stock.getSymbol());
            }

            System.out.println("Sold " + quantity + " shares of " + stock.getSymbol() +
                               " for " + StockTradingPlatform.currencyFormat.format(revenue));
        } else {
            System.out.println("Not enough shares to sell!");
        }
    }

    // Display Portfolio with Profit/Loss
    public void displayPortfolio(Map<String, Stock> market) {
        System.out.println("\n--- Portfolio ---");
        System.out.println("Balance: " + StockTradingPlatform.currencyFormat.format(balance));

        if (holdings.isEmpty()) {
            System.out.println("No holdings yet.");
        } else {
            for (Map.Entry<String, Integer> entry : holdings.entrySet()) {
                String symbol = entry.getKey();
                int quantity = entry.getValue();
                Stock stock = market.get(symbol);

                double totalValue = stock.getPrice() * quantity;
                double investedValue = avgBuyPrice.get(symbol) * quantity;
                double profitLoss = totalValue - investedValue;

                System.out.println(symbol + " - " + quantity + " shares (" +
                        StockTradingPlatform.currencyFormat.format(totalValue) + ") " +
                        "[P/L: " + StockTradingPlatform.currencyFormat.format(profitLoss) + "]");
            }
        }
        System.out.println("-----------------");
    }
}

// --------------------- StockTradingPlatform ---------------------
public class StockTradingPlatform {

    static Map<String, Stock> market = new HashMap<>();
    static Portfolio portfolio;

    // Currency Formatter for Indian Rupees
    public static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));

    // Simulate market price changes
    private static void updateMarketPrices() {
        Random rand = new Random();
        for (Stock stock : market.values()) {
            double change = (rand.nextDouble() - 0.5) * 50; // Random change between -25 and +25
            stock.setPrice(Math.max(1, stock.getPrice() + change));
        }
    }

    // Display market stocks
    private static void displayMarket() {
        System.out.println("\n--- Market Stocks ---");
        for (Stock stock : market.values()) {
            System.out.println(stock);
        }
    }

    // Save portfolio to file
    private static void savePortfolio() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("portfolio.dat"))) {
            oos.writeObject(portfolio);
            System.out.println("Portfolio saved!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load portfolio from file
    private static Portfolio loadPortfolio() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("portfolio.dat"))) {
            return (Portfolio) ois.readObject();
        } catch (Exception e) {
            System.out.println("No saved portfolio found. Starting fresh.");
            return new Portfolio(1000000); // ₹10,00,000 initial balance
        }
    }

    public static void main(String[] args) {
        // Initialize market with some stocks
        market.put("RELIANCE", new Stock("RELIANCE", 2450));
        market.put("TCS", new Stock("TCS", 3500));
        market.put("INFY", new Stock("INFY", 1520));
        market.put("HDFC", new Stock("HDFC", 1600));

        // Load existing portfolio or create a new one
        portfolio = loadPortfolio();

        Scanner sc = new Scanner(System.in);
        while (true) {
            updateMarketPrices();
            displayMarket();
            portfolio.displayPortfolio(market);

            System.out.println("\n1. Buy Stock\n2. Sell Stock\n3. Save & Exit");
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter Stock Symbol: ");
                String symbol = sc.next().toUpperCase();
                System.out.print("Enter Quantity: ");
                int qty = sc.nextInt();
                if (market.containsKey(symbol)) {
                    portfolio.buyStock(market.get(symbol), qty);
                } else {
                    System.out.println("Invalid stock symbol!");
                }

            } else if (choice == 2) {
                System.out.print("Enter Stock Symbol: ");
                String symbol = sc.next().toUpperCase();
                System.out.print("Enter Quantity: ");
                int qty = sc.nextInt();
                if (market.containsKey(symbol)) {
                    portfolio.sellStock(market.get(symbol), qty);
                } else {
                    System.out.println("Invalid stock symbol!");
                }

            } else if (choice == 3) {
                savePortfolio();
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid choice!");
            }
        }

        sc.close();
    }
}
